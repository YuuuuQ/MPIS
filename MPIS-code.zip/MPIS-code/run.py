from run_method import *


# 定义超参数
population_size = 6
num_epochs = 5
batch_size = 128
lr_sgd = 0.01
lr_adam = 0.01
fitness_p_ngde = 0.1  
F = 0.1      
niche_size = 2
gd_epochs = 1
evo_epochs = 1
prev_best_loss = float('inf') 
#=============================
F_D = 0.1 
F_G = 0.001 
w =0.1
LR_ADAM_OUR = 0.001
#=============================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
random.seed(123)
#=============================
dataname = "CIFAR100_1000"   # CIFAR10, CIFAR100
figure_save_path = "LR_sgd"+ str(lr_sgd) + "LR_adam_"+ str(lr_adam) + "F_D_" +str(F_D)+ "F_G_" + str(F_G)+ "w_"+ str(w) + "LR_adam_OUR"+ str(LR_ADAM_OUR) + "_" + str(dataname) + "_results"
run_method(dataname, batch_size, device, population_size, lr_sgd, lr_adam, LR_ADAM_OUR, num_epochs, fitness_p_ngde, F, niche_size, gd_epochs, evo_epochs, figure_save_path, F_D, F_G, w)

