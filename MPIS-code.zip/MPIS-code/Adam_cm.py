import copy
import random
from get_fitness import *
import torch
from GD_cm import train_cm


class ADAM_cm():
    def __init__(self, trainloader, testloader, valloader, criterion,
                 population_size, num_epoch):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.criterion = criterion
        self.population_size = population_size
        self.num_epoch = num_epoch
        self.device = device


    def fitness(self, population):
        Fitness = [get_loss(Individual, self.valloader, self.device, self.criterion) for Individual in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual
        
    def adam_cm(self, population, optimizars):
        adam_train_losses, adam_test_losses, adam_train_accs, adam_test_accs, adam_epoch_times = [], [], [], [], []
        adam_valid_losses, adam_valid_accs = [], []
        
        for epoch in range(self.num_epoch):
            print(f"Epoch [{epoch + 1}/{self.num_epoch}]")
            begin_time = time.time()
            updated_population = []
            
            for i, (Individual, optimizar) in enumerate(zip(population, optimizars)):
                
                update_individual, adam_train_loss, adam_train_acc, adam_time = train_cm(Individual, optimizar, self.trainloader, self.criterion)
                updated_population.append(update_individual)

            gbest_individual = self.fitness_sort(updated_population)
            population = updated_population

            end_time = time.time()
            adam_epoch_time = end_time - begin_time
            
            adam_train_loss, adam_train_acc = get_acc_loss(gbest_individual, self.trainloader, self.device, self.criterion)
            adam_test_loss, adam_test_acc = get_acc_loss(gbest_individual, self.testloader, self.device, self.criterion)
            adam_valid_loss, adam_valid_acc = get_acc_loss(gbest_individual, self.valloader, self.device, self.criterion)
            
            adam_train_losses.append(adam_train_loss)
            adam_test_losses.append(adam_test_loss)
            adam_train_accs.append(adam_train_acc)
            adam_test_accs.append(adam_test_acc)
            adam_valid_accs.append(adam_valid_acc)
            adam_valid_losses.append(adam_valid_loss)
            adam_epoch_times.append(adam_epoch_time)
            print(
                f"Adam: Train Loss: {adam_train_loss:.4f}, Train Acc: {adam_train_acc:.2f}%, "
                f"Test Loss: {adam_test_loss:.4f}, Test Acc: {adam_test_acc:.2f}%, "
                f"Valid Loss: {adam_valid_loss:.4f}, Valid Acc: {adam_valid_acc:.2f}%, "f"Time: {adam_epoch_time:.2f}s")

        return adam_train_losses, adam_test_losses, adam_valid_losses, adam_train_accs, adam_test_accs, adam_valid_accs, adam_epoch_times
