import time
import torch

# 定义训练函数
def train_cm(individual, optimizer, trainloader, criterion):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    individual.train()
    train_loss = 0
    correct = 0
    total = 0
    start_time = time.time()

    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = individual(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

    end_time = time.time()
    epoch_time = end_time - start_time

    train_loss /= len(trainloader)
    train_acc = 100.0 * correct / total

    return individual, train_loss, train_acc, epoch_time

