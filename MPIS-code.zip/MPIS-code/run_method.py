from data_load import choose_dataset
import torch.optim as optim
from CNN import *
from MPIS import *
from SGD_cm import SGD
from ESGD import ESGD
from Adam_cm import ADAM_cm
from Adam import ADAM
from draw import *
from tocsv import *
import time
from GD_cm import train_cm
from GD import train
from get_fitness import *
from fitness import *
import pandas as pd
import os
import torch.nn as nn
import random
import copy


def store_excel(Train_Accuracy_list, Train_cost_list, Test_Accuracy_list,
                Test_cost_list, Valid_cost_list, Valid_Accuracy_list,
                times, time_all, name, figure_save_path):
    # 创建一个字典来存储数据
    data = {
        'Train_Accuracy': Train_Accuracy_list,
        'Train_Cost': Train_cost_list,
        'Test_Accuracy': Test_Accuracy_list,
        'Test_Cost': Test_cost_list,
        'Valid_Cost': Valid_cost_list,
        'Valid_Accuracy': Valid_Accuracy_list,
        'Times': times,
        "time_all":time_all
    }

    df = pd.DataFrame(data)
    df_transposed = df.T
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)  
    file_path = figure_save_path + '/experiment_results_' + name + '.xlsx'
    print(file_path)
    df_transposed.to_excel(file_path, index=True)



def run_method(dataname, batch_size, device, population_size, lr_sgd, lr_adam, LR_ADAM_OUR, num_epochs, fitness_p_ngde, F, niche_size, gd_epochs, evo_epochs, figure_save_path, F_D, F_G, w):
   
    # 导入数据
    train_dataset, val_dataset, test_dataset, trainloader, valloader, testloader, n = choose_dataset(dataname, batch_size)  # CIFAR10,CIFAR100,MNIST,FashionMNIST,STL10,SVHN
    print('n:', n)

    print(f"Train dataset size: {len(train_dataset)}")
    print(f"Validation dataset size: {len(val_dataset)}")
    print(f"Test dataset size: {len(test_dataset)}")
    print(f"Number of classes: {n}")

    # 定义损失函数、种群、优化器
    criterion = nn.CrossEntropyLoss()
    figure_save_path_results = figure_save_path
    random.seed(123)
    population = [Resnet18(n).to(device) for _ in range(population_size)] 

    # ==================MPIS======================
    print("======== Running MPIS ========")
    start = time.time()
    MPIS_population = [Individual(Resnet18(n).to(device), [torch.zeros_like(param).to(device) for param in Resnet18(n).parameters()]) for _ in range(population_size)]  
    optimizers = [optim.Adam(Individual.model.parameters(), lr=LR_ADAM_OUR, weight_decay=0.0001) for Individual in MPIS_population]
    torch.cuda.empty_cache()
    mpis = MPIS(trainloader, testloader, valloader, criterion,
                 population_size, num_epochs, F_D, F_G, w)
    train_losses_mpis, test_losses_mpis, valid_losses_mpis, \
    train_accs_mpise, test_accs_mpis, valid_accs_mpis, epoch_times_mpis, \
    Train_Accuracy_list_mpis, Train_cost_list_mpis, Test_Accuracy_list_mpis, \
    Test_cost_list_mpis, Valid_Accuracy_list_mpis, Valid_cost_list_mpis, \
    times = mpis.MPIS(optimizers, MPIS_population) 

    end = time.time()
    time_mpis = (end - start) / 60

    store_excel(Train_Accuracy_list_mpis, Train_cost_list_mpis,
        Test_Accuracy_list_mpis, Test_cost_list_mpis, Valid_Accuracy_list_mpis,
        Valid_cost_list_mpis, times, time_mpis, "MPIS" + dataname, figure_save_path)


    # ==================Adam======================
    print("======== Running Adam ========")
    start = time.time()
    Adam_population = copy.deepcopy(population)
    optimizers = [
        optim.Adam(model.parameters(), lr=lr_adam, betas=(0.9, 0.999),  weight_decay=1e-4, amsgrad=True) for
        model in Adam_population]
    torch.cuda.empty_cache()
    Adam_cm = ADAM_cm(trainloader, testloader, valloader, criterion,
                population_size, num_epochs)
    adam_Train_cost_list, adam_Test_cost_list, adam_Valid_cost_list, \
    adam_Train_Accuracy_list, adam_Test_Accuracy_list, adam_Valid_Accuracy_list, adam_times = Adam_cm.adam_cm(Adam_population, optimizers)
    
    end = time.time()
    time_adam = (end - start) / 60

    store_excel(adam_Train_Accuracy_list, adam_Train_cost_list,
        adam_Test_Accuracy_list, adam_Test_cost_list, adam_Valid_cost_list,
        adam_Valid_Accuracy_list, adam_times, time_adam, "ADAM_" + dataname, figure_save_path)

    # ==================NAG======================
    print("======== Running NAG ========")
    start = time.time()
    SGD_population = copy.deepcopy(population)
    optimizers = [optim.SGD(model.parameters(), lr=lr_sgd, weight_decay=1e-4, momentum=0.9, nesterov=True) for model in SGD_population]
    torch.cuda.empty_cache()
    Sgd = SGD(trainloader, testloader, valloader, criterion, population_size, num_epochs)

    sgd_Train_cost_list, sgd_Test_cost_list, sgd_Valid_cost_list, \
    sgd_Train_Accuracy_list, sgd_Test_Accuracy_list, sgd_Valid_Accuracy_list, sgd_times = Sgd.sgd( SGD_population, optimizers)

    end = time.time()
    time_sgd = (end - start) / 60

    store_excel(sgd_Train_Accuracy_list, sgd_Train_cost_list, sgd_Test_Accuracy_list, sgd_Test_cost_list,
        sgd_Valid_cost_list, sgd_Valid_Accuracy_list, sgd_times, time_sgd, "SGD_" + dataname, figure_save_path)

    # ==================ESGD======================
    print("======== Running ESGD ========")
    start = time.time()
    ESGD_population = copy.deepcopy(population)
    optimizers = [
        optim.Adam(model.parameters(), lr=lr_adam, betas=(0.9, 0.999),  weight_decay=1e-4, amsgrad=True) for
        model in ESGD_population]
    torch.cuda.empty_cache()
    esgd = ESGD(trainloader, testloader, valloader, criterion, gd_epochs, evo_epochs,
                population_size, F, num_epochs)
    train_losses_esgd, test_losses_esgd, valid_losses_esgd, \
      train_accs_esgd, test_accs_esgd, valid_accs_esgd, epoch_times_esgd, \
            Train_Accuracy_list_esgd, Train_cost_list_esgd, Test_Accuracy_list_esgd, \
                  Test_cost_list_esgd, Valid_cost_list_esgd, Valid_Accuracy_list_esgd, \
                        times_esgd = esgd.ESGD(optimizers, ESGD_population)

    end = time.time()
    time_esgd = (end - start) / 60

    store_excel(Train_Accuracy_list_esgd, Train_cost_list_esgd, Test_Accuracy_list_esgd,
        Test_cost_list_esgd, Valid_cost_list_esgd, Valid_Accuracy_list_esgd,
        times_esgd, time_esgd, "ESGD_" + dataname, figure_save_path)

    # 定义对比优化器
    ###=======================================draw============================
    Train_Accuracy_list = [sgd_Train_Accuracy_list, Train_Accuracy_list_esgd, adam_Train_Accuracy_list, Train_Accuracy_list_mpis]
    draw_results(Train_Accuracy_list, dataname + "-Train Accuracy", "Train Accuracy", figure_save_path_results)

    Train_cost_list = [sgd_Train_cost_list, Train_cost_list_esgd, adam_Train_cost_list, Train_cost_list_mpis]
    draw_results(Train_cost_list, dataname + "-Train cost", "Train cost", figure_save_path_results)

    Test_Accuracy_list = [sgd_Test_Accuracy_list, Test_Accuracy_list_esgd, adam_Test_Accuracy_list, Test_Accuracy_list_mpis]
    draw_results(Test_Accuracy_list, dataname + "-Test Accuracy", "Test Accuracy", figure_save_path_results)

    Test_cost_list = [sgd_Test_cost_list, Test_cost_list_esgd, adam_Test_cost_list, Test_cost_list_mpis]
    draw_results(Test_cost_list, dataname + "-Test cost", "Test cost", figure_save_path_results)

    Valid_Accuracy_list = [sgd_Valid_Accuracy_list, Valid_Accuracy_list_esgd, adam_Valid_Accuracy_list, Valid_Accuracy_list_mpis]
    draw_results(Valid_Accuracy_list, dataname + "-Valid Accuracy", "Valid Accuracy", figure_save_path_results)

    Valid_cost_list = [sgd_Valid_cost_list, Valid_cost_list_esgd, adam_Valid_cost_list, Valid_cost_list_mpis]
    draw_results(Valid_cost_list, dataname + "-Valid cost", "Valid cost", figure_save_path_results)

    # ==================================time====================了
    run_time = [sgd_times, times_esgd, adam_times, times]

    # ======================================================
    tocsv(run_time, figure_save_path, dataname, Train_Accuracy_list, Train_cost_list,
          Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list)





