import pandas as pd
import os


def tocsv(run_time, figure_save_path, dataname, Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list):

    # ==================================time====================
    print("runtime:")
    print( "NAG: {}min; ESGD: {}min;ADAM: {}min; MPIS：{}min;".format(run_time[0], run_time[1], run_time[2], run_time[3]))

    index = ["SGD", "ESGD", "ADAM", "MPIS"]
    columns = [f'Run{i + 1}' for i in range(len(run_time[0]))]
    running_time = pd.DataFrame(run_time, index=index, columns=columns)
    path = figure_save_path + "/runtime:" + dataname + ".xlsx"
    running_time.to_excel(path)

    # ==================================store=========================================

    pd_msgd = pd.DataFrame([Train_Accuracy_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Train_Accuracy_list[1]], index=["ESGD"])
    pd_madam = pd.DataFrame([Train_Accuracy_list[2]], index=["ADAM"])
    pd_mpis = pd.DataFrame([Train_Accuracy_list[3]], index=["MPIS"])
    history = pd.concat([pd_msgd, pd_esgd, pd_madam, pd_mpis])
    path = figure_save_path + "/Train_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Train_cost_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Train_cost_list[1]], index=["ESGD"])
    pd_madam = pd.DataFrame([Train_cost_list[2]], index=["ADAM"])
    pd_mpis = pd.DataFrame([Train_cost_list[3]], index=["MPIS"])
    history = pd.concat([pd_msgd, pd_esgd, pd_madam, pd_mpis])
    path = figure_save_path + "/Train_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Test_Accuracy_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Test_Accuracy_list[1]], index=["ESGD"])
    pd_madam = pd.DataFrame([Test_Accuracy_list[2]], index=["ADAM"])
    pd_mpis = pd.DataFrame([Test_Accuracy_list[3]], index=["MPIS"])
    history = pd.concat([pd_msgd, pd_esgd, pd_madam, pd_mpis])
    path = figure_save_path + "/Test_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Test_cost_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Test_cost_list[1]], index=["ESGD"])
    pd_madam = pd.DataFrame([Test_cost_list[2]], index=["ADAM"])
    pd_mpis = pd.DataFrame([Test_cost_list[3]], index=["MPIS"])
    history = pd.concat([pd_msgd, pd_esgd, pd_madam, pd_mpis])
    path = figure_save_path + "/Test_cost-" + dataname + ".xlsx"
    history.to_excel(path)
    
    pd_msgd = pd.DataFrame([Valid_Accuracy_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Valid_Accuracy_list[1]], index=["ESGD"])
    pd_madam = pd.DataFrame([Valid_Accuracy_list[2]], index=["ADAM"])
    pd_mpis = pd.DataFrame([Valid_Accuracy_list[3]], index=["MPIS"])
    history = pd.concat([pd_msgd, pd_esgd, pd_madam, pd_mpis])
    path = figure_save_path + "/Valid_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)
    
    pd_msgd = pd.DataFrame([Valid_cost_list[0]], index=["SGD"])
    pd_esgd = pd.DataFrame([Valid_cost_list[1]], index=["ESGD"])
    pd_madam = pd.DataFrame([Valid_cost_list[2]], index=["ADAM"])
    pd_mpis = pd.DataFrame([Valid_cost_list[3]], index=["MPIS"])
    history = pd.concat([pd_msgd, pd_esgd, pd_madam, pd_mpis])
    path = figure_save_path + "/Valid_cost-" + dataname + ".xlsx"
    history.to_excel(path)





