
from torchvision.models import resnet18, vgg16, mobilenet_v2, densenet121, resnet50
import torch.nn as nn
import torch
import torch.nn.functional as F


class MyLeNet5(nn.Module):
    def __init__(self, n):
        super(MyLeNet5, self).__init__()
        self.c1 = nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, padding=2)
        self.Sigmoid = nn.Sigmoid()
        self.s2 = nn.AvgPool2d(kernel_size=2, stride=2)
        self.c3 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5)
        self.s4 = nn.AvgPool2d(kernel_size=2, stride=2)
        self.f5 = nn.Linear(16*5*5, 120)
        self.f6 = nn.Linear(120, 84)
        self.output = nn.Linear(84, n)

    def forward(self, x):
        x = self.Sigmoid(self.c1(x))
        x = self.s2(x)
        x = self.Sigmoid(self.c3(x))
        x = self.s4(x)
        x = x.view(-1, 16 * 5 * 5)
        x = self.f5(x)
        x = self.f6(x)
        x = self.output(x)
        return x

def LeNet5(n):
    model =  MyLeNet5(n)
    return model

def MonileNetV2(n):
    model = mobilenet_v2(pretrained=False)
    num_ftrs = model.classifier[1].in_features
    model.classifier[1] = nn.Linear(num_ftrs, n)
    return model

def DenseNet121(n):
    model = densenet121(pretrained=False)
    num_ftrs = model.classifier.in_features
    model.classifier = nn.Linear(num_ftrs, n)
    return model

def VGG16(n):
    model = vgg16(pretrained=False)
    num_features = model.classifier[6].in_features
    model.classifier[6] = nn.Linear(num_features, n)
    return model

def Resnet18(n):
    model = resnet18(num_classes=n)
    return model

def Resnet50(n):
    model = resnet50(num_classes=n)   
    return model

