import copy
import random
from get_fitness import *
import torch
from GD_cm import train_cm


class SGD():
    def __init__(self, trainloader, testloader, valloader, criterion,
                 population_size, num_epoch):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.criterion = criterion
        self.population_size = population_size
        self.num_epoch = num_epoch
        self.device = device


    def fitness(self, population):
        Fitness = [get_loss(Individual, self.valloader, self.device, self.criterion) for Individual in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual
        
    def sgd(self, population, optimizars):
        sgd_train_losses, sgd_test_losses, sgd_train_accs, sgd_test_accs, sgd_epoch_times = [], [], [], [], []
        sgd_valid_losses, sgd_valid_accs = [], []
        
        for epoch in range(self.num_epoch):
            print(f"Epoch [{epoch + 1}/{self.num_epoch}]")
            begin_time = time.time()
            updated_population = []
            
            for i, (Individual, optimizar) in enumerate(zip(population, optimizars)):
                
                update_individual, sgd_train_loss, sgd_train_acc, sgd_time = train_cm(Individual, optimizar, self.trainloader, self.criterion)
                updated_population.append(update_individual)

            gbest_individual = self.fitness_sort(updated_population)
            population = updated_population

            end_time = time.time()
            sgd_epoch_time = end_time - begin_time
            
            sgd_train_loss, sgd_train_acc = get_acc_loss(gbest_individual, self.trainloader, self.device, self.criterion)
            sgd_test_loss, sgd_test_acc = get_acc_loss(gbest_individual, self.testloader, self.device, self.criterion)
            sgd_valid_loss, sgd_valid_acc = get_acc_loss(gbest_individual, self.valloader, self.device, self.criterion)
            
            sgd_train_losses.append(sgd_train_loss)
            sgd_test_losses.append(sgd_test_loss)
            sgd_train_accs.append(sgd_train_acc)
            sgd_test_accs.append(sgd_test_acc)
            sgd_valid_accs.append(sgd_valid_acc)
            sgd_valid_losses.append(sgd_valid_loss)
            sgd_epoch_times.append(sgd_epoch_time)
            print(
                f"Adam: Train Loss: {sgd_train_loss:.4f}, Train Acc: {sgd_train_acc:.2f}%, "
                f"Test Loss: {sgd_test_loss:.4f}, Test Acc: {sgd_test_acc:.2f}%, "
                f"Valid Loss: {sgd_valid_loss:.4f}, Valid Acc: {sgd_valid_acc:.2f}%, "f"Time: {sgd_epoch_time:.2f}s")

        return sgd_train_losses, sgd_test_losses, sgd_valid_losses, sgd_train_accs, sgd_test_accs, sgd_valid_accs, sgd_epoch_times
