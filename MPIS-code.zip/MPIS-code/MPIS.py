import copy
import random
import time
from CNN import *
from fitness import *
import numpy as np


class Individual:
    def __init__(self, model, velocity):
        self.model = model
        self.velocity = velocity


class MPIS():

    def __init__(self, trainloader, testloader, valloader, criterion,
                 population_size, num_epoch, F_D, F_G, w):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.device = device
        self.criterion = criterion
        self.population_size = population_size
        self.num_epoch = num_epoch
        self.t = 0

        self.F_D = F_D  # 群体学习系数
        self.F_G = F_G  # 个体学习系数
        self.w = w      # 惯性权重
    
    
    # 定义最优个体更新函数
    def MPIS_update1(self, Individual, optimizer):
        Individual.model.train()
        start_time = time.time()

        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            # 参数更新
            optimizer.zero_grad()
            outputs = Individual.model(inputs)
            loss = self.criterion(outputs, targets)
            loss.backward()
            optimizer.step()

        end_time = time.time()
        epoch_time = end_time - start_time

        return Individual, epoch_time

    # 定义次优个体更新函数
    def MPIS_update2(self, Individual, gbest_Individual, optimizer):
        Individual.model.train()
        start_time = time.time()
        # 向最优学习
        for param, gbest_param in zip(Individual.model.parameters(), gbest_Individual.model.parameters()):
            # y_t = x_t + F_D * (x_best - x_t-1) 
            param.data = param.data + self.F_D * (gbest_param.data - param.data) 
        
        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            optimizer.zero_grad()
            outputs = Individual.model(inputs)
            loss = self.criterion(outputs, targets)
            loss.backward()
            # optimizer.step()
            # 更新策略：v_t = w * v_t-1 - F_G * 差分后的梯度方向
            with torch.no_grad():
                for d, (param, velocity) in enumerate(zip(Individual.model.parameters(), Individual.velocity)):
                    Individual.velocity[d] = self.w * velocity - self.F_G * param.grad
                    param.data = param.data + Individual.velocity[d]

        end_time = time.time()
        epoch_time = end_time - start_time

        return Individual, epoch_time


    def MPIS_update3(self, population, Individual, optimizer):
        Individual.model.train()
        start_time = time.time()
                    
        j, k = random.sample(range(self.population_size), 2)
        xj, xk = population[j].model.parameters(), population[k].model.parameters()
        for param, param_j, param_k in zip(Individual.model.parameters(), xj, xk):
            # y_t = x_t + F_D * (x_t - x_k) 
            param.data = param.data + self.F_D * (param_j.data - param_k.data) 
        
        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            optimizer.zero_grad()
            outputs = Individual.model(inputs)
            loss = self.criterion(outputs, targets)
            loss.backward()
            # optimizer.step()
            # 更新策略：v_t = w * v_t-1  - F_G * 差分后的梯度方向
            with torch.no_grad():
                for d, (param, velocity) in enumerate(zip(Individual.model.parameters(), Individual.velocity)):
                    Individual.velocity[d] = self.w * velocity - self.F_G * param.grad
                    param.data = param.data + Individual.velocity[d]
                        
        end_time = time.time()
        epoch_time = end_time - start_time

        return Individual, epoch_time
    

    

    def update(self, individual, gbest_Individual, population, optimizer, Individual_label):
        Individual_fitness = loss(individual, self.valloader, self.device, self.criterion)
        
        if Individual_label == 0: 
            update_Individual, epoch_time = self.MPIS_update1(individual, optimizer)
            update_Individual_fitness = loss(update_Individual, self.valloader, self.device, self.criterion)
            print("fitness:", Individual_fitness, "; update by Adam:", update_Individual_fitness)
            return update_Individual_fitness, update_Individual, epoch_time
        elif Individual_label == 1: 
            update_Individual, epoch_time = self.MPIS_update2(individual, gbest_Individual, optimizer)
            update_Individual_fitness = loss(update_Individual, self.valloader, self.device, self.criterion)
            print("fitness:", Individual_fitness,"; update by best:", update_Individual_fitness)
            return update_Individual_fitness, update_Individual, epoch_time
        else:                        
            update_Individual, epoch_time = self.MPIS_update3(population, individual, optimizer)
            update_Individual_fitness = loss(update_Individual, self.valloader, self.device, self.criterion)
            print("fitness:", Individual_fitness,"; update by random:", update_Individual_fitness)
            return update_Individual_fitness, update_Individual, epoch_time


    def fitness(self, population):
        Fitness = [loss(Individual, self.valloader, self.device, self.criterion) for Individual in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual, Fitness, Fitness_sort
    
    def sort_population(self, Fitness):
        # 对种群个体进行排序，按照Fitness值从小到大排序
        sorted_indices = [i for i, _ in sorted(enumerate(Fitness), key=lambda x: x[1], reverse=False)]

        individual_labels = [2] * self.population_size  # 初始化所有元素为2
        individual_labels[sorted_indices[0]] = 0  # 最优个体标签为0
        for i in range(1, int(self.population_size * 0.9)):
            individual_labels[sorted_indices[i]] = 1  

        print("sorted_indices:", sorted_indices)
        print("individual_labels:",individual_labels)
        return individual_labels

    
    def get_best_individual(self, Fitness):
        # 找到最小值
        min_fitness = min(Fitness)
        # 找到最小值对应的索引
        min_index = Fitness.index(min_fitness)
        return min_index


    def MPIS(self, optimizers, population):

        # 训练模型
        train_losses_all, test_losses_all, valid_losses_all = [], [], []
        train_accs_all, test_accs_all, valid_accs_all = [], [], []
        epoch_times_all = []
        
        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list = [], [], [], []
        Valid_Accuracy_list, Valid_cost_list = [], []
        times = []

        gbest_Individual, Fitness, Fitness_sort = self.fitness_sort(population)
        print("Fitness_p:",Fitness)
        Individual_labels = [0] * self.population_size

        while self.t < self.num_epoch:
            print(f"Epoch [{self.t + 1}/{self.num_epoch}]")
            train_losses, test_losses, valid_losses = [], [], []
            train_accs, test_accs, valid_accs = [], [], []
            epoch_times = []
            updated_population = []
            begin_time = time.time()
            for i, (Individual, optimizer) in enumerate(zip(population, optimizers)):
                Individual_label = Individual_labels[i]
                update_Individual_fitness, updated_Individual, updated_epoch_time = self.update(Individual, gbest_Individual, population, optimizer, Individual_label)
                updated_population.append(updated_Individual)

                
                test_loss, test_acc = acc_loss(updated_Individual, self.testloader, self.device, self.criterion)
                train_loss, train_acc = acc_loss(updated_Individual, self.trainloader, self.device, self.criterion)
                valid_loss, valid_acc = acc_loss(updated_Individual, self.valloader, self.device, self.criterion)
               
                train_losses.append(train_loss)
                test_losses.append(test_loss)
                valid_losses.append(valid_loss)
                train_accs.append(train_acc)
                test_accs.append(test_acc)
                valid_accs.append(valid_acc)
                epoch_times.append(updated_epoch_time)

                print(
                    f"Individual {i + 1}: Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
                    f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%, "
                    f"Valid Loss: {valid_loss:.4f}, Valid Acc: {valid_acc:.2f}%, Time: {updated_epoch_time:.2f}s")

            
            train_losses_all.append(list(train_losses))
            test_losses_all.append(list(test_losses))
            valid_losses_all.append(list(valid_losses))
            train_accs_all.append(list(train_accs))
            test_accs_all.append(list(test_accs))
            valid_accs_all.append(list(valid_accs))
            epoch_times_all.append(list(epoch_times))

            population = updated_population
            best_fitness_index = self.get_best_individual(valid_losses)
            Individual_labels = self.sort_population(valid_losses)

            
            end_time = time.time()
            epoch_time_all = end_time - begin_time
            self.t += 1

            # 最优个体
            test_loss_best, test_acc_best = test_losses[best_fitness_index], test_accs[best_fitness_index]
            train_loss_best, train_acc_best = train_losses[best_fitness_index], train_accs[best_fitness_index]
            valid_loss_best, valid_acc_best = valid_losses[best_fitness_index], valid_accs[best_fitness_index]
                        
            print(
                f"Best Individual: Train Loss: {train_loss_best:.4f}, Train Acc: {train_acc_best:.2f}%, "
                f"Test Loss: {test_loss_best:.4f}, Test Acc: {test_acc_best:.2f}%, "
                f"Valid Loss: {valid_loss_best:.4f}, Valid Acc: {valid_acc_best:.2f}%, "
                f"time_all:{epoch_time_all:.2f}s")
            

            # 存储每一代中最优个体的精度和损失
            Train_cost_list.append(train_loss_best)
            Test_cost_list.append(test_loss_best)
            Valid_cost_list.append(valid_loss_best)
            Train_Accuracy_list.append(train_acc_best)
            Test_Accuracy_list.append(test_acc_best)
            Valid_Accuracy_list.append(valid_acc_best)
            
            times.append(epoch_time_all)

        return train_losses_all, test_losses_all, valid_losses_all, train_accs_all, test_accs_all, valid_accs_all, epoch_times_all, \
               Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list, \
               times




